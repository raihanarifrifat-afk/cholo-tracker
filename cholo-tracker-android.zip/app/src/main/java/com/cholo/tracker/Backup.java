package com.cholo.tracker;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/** Full backup and restore of all workouts as one JSON document (optionally inside a ZIP). */
final class Backup {

    static final int FORMAT = 1;

    private Backup() {
    }

    static String json(Context c) throws JSONException {
        synchronized (TrackService.LOCK) {
            JSONObject o = new JSONObject();
            o.put("app", "pacevia");
            o.put("format", FORMAT);
            o.put("created", System.currentTimeMillis());
            o.put("goal", TrackService.prefs(c).getInt("goal", 5));
            o.put("settings", new JSONObject(TrackService.settingsJson(c)));
            JSONArray acts = new JSONArray(TrackService.activitiesJson(c));
            JSONObject paths = new JSONObject();
            for (int i = 0; i < acts.length(); i++) {
                long id = acts.getJSONObject(i).optLong("id");
                String p = TrackService.readFile(TrackService.pathFile(c, id));
                if (p != null) paths.put(String.valueOf(id), new JSONArray(p));
            }
            o.put("acts", acts);
            o.put("paths", paths);
            return o.toString();
        }
    }

    static byte[] bytes(Context c, boolean zip) throws JSONException, IOException {
        byte[] raw = json(c).getBytes(StandardCharsets.UTF_8);
        if (!zip) return raw;
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        try (ZipOutputStream z = new ZipOutputStream(buf)) {
            z.putNextEntry(new ZipEntry("pacevia-backup.json"));
            z.write(raw);
            z.closeEntry();
        }
        return buf.toByteArray();
    }

    /**
     * Adds the workouts from a backup that are not on this phone yet. Nothing existing is changed
     * or deleted. Returns the number of workouts added, or -1 if the file is not a Pacevia backup.
     */
    static int restore(Context c, byte[] data) {
        try {
            if (data.length > 2 && data[0] == 'P' && data[1] == 'K') data = unzip(data);
            if (data == null) return -1;
            JSONObject o = new JSONObject(new String(data, StandardCharsets.UTF_8));
            if (!"pacevia".equals(o.optString("app")) || o.optInt("format", 0) > FORMAT) return -1;
            JSONArray in = o.optJSONArray("acts");
            if (in == null) return -1;
            JSONObject paths = o.optJSONObject("paths");
            synchronized (TrackService.LOCK) {
                JSONArray cur = new JSONArray(TrackService.activitiesJson(c));
                HashSet<Long> have = new HashSet<>();
                ArrayList<JSONObject> all = new ArrayList<>();
                for (int i = 0; i < cur.length(); i++) {
                    JSONObject a = cur.getJSONObject(i);
                    have.add(a.optLong("id"));
                    all.add(a);
                }
                int added = 0;
                for (int i = 0; i < in.length(); i++) {
                    JSONObject a = in.optJSONObject(i);
                    if (a == null) continue;
                    long id = a.optLong("id", 0);
                    // validation: a workout needs an id, a start time and sane numbers
                    if (id <= 0 || a.optLong("start", 0) <= 0 || a.optDouble("dist", -1) < 0
                            || a.optDouble("secs", -1) < 0 || have.contains(id)) continue;
                    if (!a.has("walk")) a.put("walk", a.optDouble("dist"));
                    if (!a.has("run")) a.put("run", 0);
                    if (!a.has("name")) a.put("name", "Workout");
                    JSONArray p = paths == null ? null : paths.optJSONArray(String.valueOf(id));
                    if (p != null && !TrackService.writeFile(TrackService.pathFile(c, id), p.toString())) continue;
                    have.add(id);
                    all.add(a);
                    added++;
                }
                if (added > 0) {
                    Collections.sort(all, new Comparator<JSONObject>() {
                        @Override
                        public int compare(JSONObject x, JSONObject y) {
                            return Long.compare(y.optLong("start"), x.optLong("start"));
                        }
                    });
                    JSONArray out = new JSONArray();
                    for (JSONObject a : all) out.put(a);
                    if (!TrackService.prefs(c).edit().putString("acts", out.toString()).commit()) return -1;
                }
                return added;
            }
        } catch (JSONException | IOException | RuntimeException e) {
            return -1;
        }
    }

    private static byte[] unzip(byte[] data) throws IOException {
        try (ZipInputStream z = new ZipInputStream(new ByteArrayInputStream(data))) {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                if (!e.getName().endsWith(".json")) continue;
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                byte[] b = new byte[8192];
                int n;
                while ((n = z.read(b)) > 0) {
                    buf.write(b, 0, n);
                    if (buf.size() > 80 * 1024 * 1024) return null;
                }
                return buf.toByteArray();
            }
        }
        return null;
    }
}
