package com.cholo.tracker;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationRequest;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executor;

/**
 * Foreground service that records one workout (a walk or run): reads location,
 * adds up distance and moving time, keeps going with the screen off, and saves
 * the finished workout with its route.
 */
public class TrackService extends Service implements LocationListener, SensorEventListener {

    static final String ACTION_FINISH = "com.cholo.tracker.FINISH";
    static final String ACTION_PAUSE = "com.cholo.tracker.PAUSE";
    static final String ACTION_RESUME = "com.cholo.tracker.RESUME";
    static final String CHANNEL = "tracking";
    static final int NOTIF_ID = 1;

    static final int IDLE = 0, REC = 1, PAUSED = 2;

    static final double MAX_MS = 8.0;    // faster than this is a vehicle or a location jump
    static final double MIN_SAVE_M = 20; // shorter workouts are not saved
    static final int MAX_SAVED_POINTS = 3000;

    static final Object LOCK = new Object();
    static volatile int state = IDLE;
    static volatile boolean discard = false;
    static volatile boolean resetAnchor = false;
    static volatile boolean autoPaused = false;
    static volatile double curSpeed = 0;
    static volatile String mode = "walk";
    static volatile String msg = "";
    static volatile String mapMsg = "";
    static volatile double lastLat = Double.NaN, lastLon = Double.NaN;
    static volatile float lastAcc = -1;
    static volatile long lastLocAt = 0;      // elapsedRealtime of the newest location of any quality
    static volatile boolean stepsAvail = false;

    // settings the recorder uses (the UI owns the full settings object)
    static volatile boolean sAutoPause = false, sVoice = false, sVDist = true, sVPace = true, sVTime = false;
    static volatile double sRunKmh = 7.0, sVoiceEvery = 1.0;
    static volatile float sMaxAcc = 35f;     // metres; worse fixes are shown on the map but not counted
    static volatile boolean sMiles = false, sAutoLap = false;
    static volatile String sVLang = "en-US";

    // the workout being recorded (guarded by LOCK)
    static long sid = 0;
    static long activeMs = 0, walkMs = 0, runMs = 0;
    static double walk = 0, run = 0, maxSp = 0, elev = 0;
    static int steps = 0, pauses = 0;
    static final ArrayList<double[]> path = new ArrayList<>(); // lat, lon, run?, activeSecs, metres, altitude, elapsedSecs
    static final ArrayList<long[]> laps = new ArrayList<>();   // metres, activeMs at the moment the lap was marked

    private LocationManager lm;
    private Handler handler;
    private PowerManager.WakeLock wakeLock;
    private Location anchor;
    private long lastFixAt = 0;
    private long lastTick = 0;
    private long startEl = 0;
    private int tickCount = 0;
    private final int[] modeVotes = {0};
    private double altSmooth = Double.NaN, altRef = Double.NaN;
    private double nextVoiceM = 0, nextLapM = 0;

    // Movement check from the phone's motion sensor, so standing still never adds distance.
    private SensorManager sm;
    private double accMean = 9.8, accVar = 0;
    private long lastSensorAt = 0, lastShakeAt = 0;
    private int goodFixes = 0;

    private TextToSpeech tts;
    private boolean ttsReady = false;
    private String ttsPending = null;
    private AudioFocusRequest focusReq;

    // ---------- storage ----------

    static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("cholo", Context.MODE_PRIVATE);
    }

    static File liveFile(Context c) {
        return new File(c.getApplicationContext().getFilesDir(), "live.json");
    }

    static File pathFile(Context c, long id) {
        return new File(c.getApplicationContext().getFilesDir(), "act_" + id + ".json");
    }

    static String readFile(File f) {
        if (!f.exists()) return null;
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] b = new byte[(int) f.length()];
            int off = 0, n;
            while (off < b.length && (n = in.read(b, off, b.length - off)) > 0) off += n;
            return new String(b, 0, off, StandardCharsets.UTF_8);
        } catch (IOException e) {
            return null;
        }
    }

    /** Writes to a temporary file first, so a crash mid-write never leaves a half-written file. */
    static boolean writeFile(File f, String s) {
        File tmp = new File(f.getPath() + ".tmp");
        try (FileOutputStream o = new FileOutputStream(tmp)) {
            o.write(s.getBytes(StandardCharsets.UTF_8));
            o.getFD().sync();
        } catch (IOException e) {
            tmp.delete();
            return false;
        }
        return tmp.renameTo(f);
    }

    static String activitiesJson(Context c) {
        synchronized (LOCK) {
            return prefs(c).getString("acts", "[]");
        }
    }

    static String activityJson(Context c, long id) {
        synchronized (LOCK) {
            try {
                JSONArray arr = new JSONArray(activitiesJson(c));
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject a = arr.getJSONObject(i);
                    if (a.optLong("id") == id) {
                        String p = readFile(pathFile(c, id));
                        a.put("path", p == null ? new JSONArray() : new JSONArray(p));
                        return a.toString();
                    }
                }
            } catch (JSONException ignored) {
            }
            return "null";
        }
    }

    static void deleteActivity(Context c, long id) {
        synchronized (LOCK) {
            try {
                JSONArray arr = new JSONArray(activitiesJson(c));
                JSONArray out = new JSONArray();
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject a = arr.getJSONObject(i);
                    if (a.optLong("id") != id) out.put(a);
                }
                prefs(c).edit().putString("acts", out.toString()).commit();
            } catch (JSONException ignored) {
            }
            pathFile(c, id).delete();
        }
    }

    /** Changes only the name and the walk/run label of a saved workout; recorded data is never touched. */
    static void updateActivity(Context c, long id, String name, String type) {
        synchronized (LOCK) {
            try {
                JSONArray arr = new JSONArray(activitiesJson(c));
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject a = arr.getJSONObject(i);
                    if (a.optLong("id") != id) continue;
                    String n = name == null ? "" : name.trim();
                    if (n.length() > 60) n = n.substring(0, 60);
                    if (n.length() > 0) a.put("name", n);
                    if ("walk".equals(type) || "run".equals(type)) a.put("type", type);
                }
                prefs(c).edit().putString("acts", arr.toString()).commit();
            } catch (JSONException ignored) {
            }
        }
    }

    static void clearAll(Context c) {
        synchronized (LOCK) {
            if (state != IDLE) return;
            File[] files = c.getApplicationContext().getFilesDir().listFiles();
            if (files != null) {
                for (File f : files) {
                    if (f.getName().startsWith("act_")) f.delete();
                }
            }
            prefs(c).edit().putString("acts", "[]").commit();
        }
    }

    static void setGoal(Context c, int goal) {
        prefs(c).edit().putInt("goal", Math.max(1, Math.min(100, goal))).apply();
    }

    static String settingsJson(Context c) {
        return prefs(c).getString("settings", "{}");
    }

    static void setSettings(Context c, String json) {
        try {
            new JSONObject(json);
        } catch (JSONException e) {
            return;
        }
        prefs(c).edit().putString("settings", json).apply();
        applySettings(c);
    }

    static void applySettings(Context c) {
        try {
            JSONObject s = new JSONObject(settingsJson(c));
            sAutoPause = s.optBoolean("autoPause", false);
            sAutoLap = s.optBoolean("autoLap", false);
            sVoice = s.optBoolean("voice", false);
            sVDist = s.optBoolean("vDist", true);
            sVPace = s.optBoolean("vPace", true);
            sVTime = s.optBoolean("vTime", false);
            sVLang = s.optString("vLang", "en-US");
            sMiles = "mi".equals(s.optString("unit", "km"));
            sRunKmh = Math.max(5.0, Math.min(10.0, s.optDouble("runKmh", 7.0)));
            sVoiceEvery = Math.max(0.5, Math.min(5.0, s.optDouble("voiceEvery", 1.0)));
            sMaxAcc = (float) Math.max(15.0, Math.min(60.0, s.optDouble("gpsAcc", 35.0)));
        } catch (JSONException ignored) {
        }
    }

    static double unitM() {
        return sMiles ? 1609.344 : 1000.0;
    }

    /** Route points for saving. extra = also write the elapsed-time column used for recovery and GPX. */
    private static JSONArray pathArray(int maxPoints) throws JSONException {
        JSONArray p = new JSONArray();
        int n = path.size();
        int step = (maxPoints > 0 && n > maxPoints) ? (int) Math.ceil(n / (double) maxPoints) : 1;
        for (int i = 0; i < n; i++) {
            if (i % step != 0 && i != n - 1) continue;
            double[] pt = path.get(i);
            JSONArray a = new JSONArray();
            a.put(Math.round(pt[0] * 1e6) / 1e6);
            a.put(Math.round(pt[1] * 1e6) / 1e6);
            a.put((int) pt[2]);
            a.put(Math.round(pt[3]));
            a.put(Math.round(pt[4] * 10) / 10.0);
            if (Double.isNaN(pt[5])) a.put(JSONObject.NULL);
            else a.put(Math.round(pt[5] * 10) / 10.0);
            a.put(Math.round(pt[6]));
            p.put(a);
        }
        return p;
    }

    private static String nameFor(long startMs, boolean isRun) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(startMs);
        int h = cal.get(Calendar.HOUR_OF_DAY);
        String part = h < 5 ? "Night" : h < 12 ? "Morning" : h < 17 ? "Afternoon" : h < 20 ? "Evening" : "Night";
        return part + (isRun ? " Run" : " Walk");
    }

    private static JSONArray lapsArray() throws JSONException {
        JSONArray out = new JSONArray();
        long prevD = 0, prevMs = 0;
        for (long[] l : laps) {
            JSONObject o = new JSONObject();
            o.put("d", l[0] - prevD);
            o.put("s", (l[1] - prevMs) / 1000);
            out.put(o);
            prevD = l[0];
            prevMs = l[1];
        }
        long total = Math.round(walk + run);
        if (!laps.isEmpty() && total - prevD >= 10) {
            JSONObject o = new JSONObject();
            o.put("d", total - prevD);
            o.put("s", (activeMs - prevMs) / 1000);
            out.put(o);
        }
        return out;
    }

    /** Saves the current session as a workout. Returns false if it was too short to keep. */
    static boolean saveSession(Context c) {
        synchronized (LOCK) {
            boolean saved = false;
            double dist = walk + run;
            if (sid > 0 && dist >= MIN_SAVE_M) {
                try {
                    JSONObject a = new JSONObject();
                    a.put("v", 2);
                    a.put("id", sid);
                    a.put("name", nameFor(sid, run > walk));
                    a.put("start", sid);
                    a.put("secs", activeMs / 1000);
                    a.put("dist", Math.round(dist));
                    a.put("walk", Math.round(walk));
                    a.put("run", Math.round(run));
                    a.put("walkSecs", walkMs / 1000);
                    a.put("runSecs", runMs / 1000);
                    a.put("maxSp", Math.round(maxSp * 100) / 100.0);
                    a.put("elev", Math.round(elev));
                    a.put("steps", stepsAvail ? steps : -1);
                    a.put("pauses", pauses);
                    a.put("laps", lapsArray());
                    int n = path.size();
                    if (n > 1) {
                        // Best efforts use elapsed (wall clock) time, so pausing can never improve a record.
                        double[] d = new double[n], t = new double[n];
                        for (int i = 0; i < n; i++) {
                            d[i] = path.get(i)[4];
                            t[i] = path.get(i)[6];
                        }
                        a.put("el", Math.round(t[n - 1]));
                        putBest(a, "b1", Calc.bestEffort(d, t, n, 1000));
                        putBest(a, "b5", Calc.bestEffort(d, t, n, 5000));
                        putBest(a, "b10", Calc.bestEffort(d, t, n, 10000));
                    }
                    if (writeFile(pathFile(c, sid), pathArray(MAX_SAVED_POINTS).toString())) {
                        JSONArray arr = new JSONArray(activitiesJson(c));
                        JSONArray out = new JSONArray();
                        out.put(a);
                        for (int i = 0; i < arr.length(); i++) {
                            if (arr.getJSONObject(i).optLong("id") != sid) out.put(arr.get(i));
                        }
                        saved = prefs(c).edit().putString("acts", out.toString()).commit();
                    }
                } catch (JSONException ignored) {
                }
                if (!saved) {
                    // Storage failed: keep the session on disk so the next launch can try again.
                    writeSnapshot(c);
                    return false;
                }
            }
            clearSession();
            liveFile(c).delete();
            return saved;
        }
    }

    private static void putBest(JSONObject a, String key, double secs) throws JSONException {
        if (secs > 0) a.put(key, Math.round(secs));
    }

    static void clearSession() {
        synchronized (LOCK) {
            sid = 0;
            activeMs = 0;
            walkMs = 0;
            runMs = 0;
            walk = 0;
            run = 0;
            maxSp = 0;
            elev = 0;
            steps = 0;
            pauses = 0;
            path.clear();
            laps.clear();
            autoPaused = false;
        }
    }

    private static void writeSnapshot(Context c) {
        synchronized (LOCK) {
            try {
                JSONObject o = new JSONObject();
                o.put("sid", sid);
                o.put("ms", activeMs);
                o.put("walkMs", walkMs);
                o.put("runMs", runMs);
                o.put("walk", walk);
                o.put("run", run);
                o.put("maxSp", maxSp);
                o.put("elev", elev);
                o.put("steps", steps);
                o.put("stepsAvail", stepsAvail);
                o.put("pauses", pauses);
                JSONArray l = new JSONArray();
                for (long[] lap : laps) l.put(new JSONArray().put(lap[0]).put(lap[1]));
                o.put("laps", l);
                o.put("path", pathArray(0));
                writeFile(liveFile(c), o.toString());
            } catch (JSONException ignored) {
            }
        }
    }

    /** If the app was killed in the middle of a recording, save what was recorded. */
    static void recover(Context c) {
        synchronized (LOCK) {
            if (state != IDLE) return;
            String s = readFile(liveFile(c));
            if (s == null) return;
            try {
                JSONObject o = new JSONObject(s);
                clearSession();
                sid = o.optLong("sid");
                activeMs = o.optLong("ms");
                walkMs = o.optLong("walkMs");
                runMs = o.optLong("runMs");
                walk = o.optDouble("walk", 0);
                run = o.optDouble("run", 0);
                maxSp = o.optDouble("maxSp", 0);
                elev = o.optDouble("elev", 0);
                steps = o.optInt("steps", 0);
                stepsAvail = o.optBoolean("stepsAvail", false);
                pauses = o.optInt("pauses", 0);
                JSONArray l = o.optJSONArray("laps");
                if (l != null) {
                    for (int i = 0; i < l.length(); i++) {
                        JSONArray a = l.getJSONArray(i);
                        laps.add(new long[]{a.getLong(0), a.getLong(1)});
                    }
                }
                JSONArray p = o.optJSONArray("path");
                if (p != null) {
                    for (int i = 0; i < p.length(); i++) {
                        JSONArray a = p.getJSONArray(i);
                        if (a.length() >= 7) {
                            path.add(new double[]{a.getDouble(0), a.getDouble(1), a.getInt(2), a.getDouble(3),
                                    a.getDouble(4), a.isNull(5) ? Double.NaN : a.getDouble(5), a.getDouble(6)});
                        } else {
                            path.add(new double[]{a.getDouble(0), a.getDouble(1), a.getInt(2), 0, 0, Double.NaN, 0});
                        }
                    }
                }
                saveSession(c);
                if (sid != 0) clearSession(); // could not be written; live.json stays for the next launch
            } catch (JSONException e) {
                clearSession();
                liveFile(c).delete();
            }
        }
    }

    // ---------- state for the UI ----------

    static String stateJson(Context c) {
        synchronized (LOCK) {
            try {
                if (Double.isNaN(lastLat)) lastKnown(c);
                long now = SystemClock.elapsedRealtime();
                JSONObject o = new JSONObject();
                o.put("state", state == REC ? "rec" : state == PAUSED ? "paused" : "idle");
                o.put("auto", state == REC && autoPaused);
                o.put("sid", sid);
                o.put("secs", activeMs / 1000);
                o.put("walk", walk);
                o.put("run", run);
                o.put("dist", walk + run);
                o.put("walkSecs", walkMs / 1000);
                o.put("runSecs", runMs / 1000);
                o.put("speed", state == REC && !autoPaused ? curSpeed : 0);
                o.put("maxSp", maxSp);
                o.put("mode", mode);
                o.put("msg", msg);
                o.put("mapMsg", mapMsg);
                o.put("n", path.size());
                o.put("goal", prefs(c).getInt("goal", 5));
                o.put("acc", lastAcc);
                o.put("steps", stepsAvail ? steps : -1);
                o.put("laps", laps.size());
                long lapD = 0, lapMs = 0;
                if (!laps.isEmpty()) {
                    lapD = laps.get(laps.size() - 1)[0];
                    lapMs = laps.get(laps.size() - 1)[1];
                }
                o.put("lapDist", walk + run - lapD);
                o.put("lapSecs", (activeMs - lapMs) / 1000);
                String gps = "off";
                if (state != IDLE) {
                    if (lastLocAt == 0 || now - lastLocAt > 10000) gps = "searching";
                    else if (lastAcc < 0 || lastAcc > sMaxAcc) gps = "weak";
                    else gps = "ready";
                }
                o.put("gps", gps);
                if (!Double.isNaN(lastLat)) {
                    o.put("lat", lastLat);
                    o.put("lon", lastLon);
                }
                return o.toString();
            } catch (JSONException e) {
                return "{}";
            }
        }
    }

    static String pathJson(int from) {
        synchronized (LOCK) {
            JSONArray p = new JSONArray();
            try {
                for (int i = Math.max(0, from); i < path.size(); i++) {
                    double[] pt = path.get(i);
                    JSONArray a = new JSONArray();
                    a.put(pt[0]);
                    a.put(pt[1]);
                    a.put((int) pt[2]);
                    p.put(a);
                }
            } catch (JSONException ignored) {
            }
            return p.toString();
        }
    }

    private static void lastKnown(Context c) {
        if (c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        try {
            LocationManager m = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
            Location best = null;
            for (String p : m.getAllProviders()) {
                Location l = m.getLastKnownLocation(p);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            }
            if (best != null) {
                lastLat = best.getLatitude();
                lastLon = best.getLongitude();
                lastAcc = best.hasAccuracy() ? best.getAccuracy() : -1;
            }
        } catch (RuntimeException ignored) {
        }
    }

    static void setPaused(boolean paused) {
        synchronized (LOCK) {
            if (state == IDLE) return;
            if (paused && state == REC) pauses++;
            state = paused ? PAUSED : REC;
            autoPaused = false;
            resetAnchor = true;
            curSpeed = 0;
        }
    }

    static void addLap() {
        synchronized (LOCK) {
            if (state == IDLE) return;
            long d = Math.round(walk + run);
            long prev = laps.isEmpty() ? 0 : laps.get(laps.size() - 1)[0];
            if (d - prev < 10) return; // ignore double taps
            laps.add(new long[]{d, activeMs});
        }
    }

    // ---------- service ----------

    /** Kept in its own class so older Android versions never load LocationRequest. */
    private static final class Api31 {
        static void request(LocationManager lm, String provider, Executor ex, LocationListener l) {
            LocationRequest r = new LocationRequest.Builder(1000L)
                    .setQuality(LocationRequest.QUALITY_HIGH_ACCURACY)
                    .setMinUpdateIntervalMillis(1000L)
                    .build();
            lm.requestLocationUpdates(provider, r, ex, l);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        handler = new Handler(Looper.getMainLooper());
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Workout recording", NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        nm.createNotificationChannel(ch);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_FINISH.equals(action)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_PAUSE.equals(action) || ACTION_RESUME.equals(action)) {
            if (state == IDLE) {
                stopSelf();
                return START_NOT_STICKY;
            }
            setPaused(ACTION_PAUSE.equals(action));
            getSystemService(NotificationManager.class).notify(NOTIF_ID, buildNotification());
            return START_NOT_STICKY;
        }
        if (state == IDLE) begin();
        return START_NOT_STICKY;
    }

    private void begin() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            } else {
                startForeground(NOTIF_ID, buildNotification());
            }
        } catch (RuntimeException e) {
            msg = "Could not start tracking. Please allow Location permission.";
            stopSelf();
            return;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            msg = "Location permission was not granted.";
            stopSelf();
            return;
        }
        if (!requestUpdates()) {
            msg = "Location is not available on this phone.";
            stopSelf();
            return;
        }
        applySettings(this);
        synchronized (LOCK) {
            clearSession();
            sid = System.currentTimeMillis();
            state = REC;
        }
        discard = false;
        resetAnchor = false;
        anchor = null;
        curSpeed = 0;
        mode = "walk";
        modeVotes[0] = 0;
        altSmooth = Double.NaN;
        altRef = Double.NaN;
        nextVoiceM = sVoiceEvery * unitM();
        nextLapM = unitM();
        lastLocAt = 0;
        msg = lm.isProviderEnabled(LocationManager.GPS_PROVIDER) ? "" : "Turn on Location (GPS) on your phone.";

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "cholo:track");
        wakeLock.setReferenceCounted(false);
        wakeLock.acquire();

        lastTick = SystemClock.elapsedRealtime();
        startEl = lastTick;
        lastFixAt = lastTick;
        goodFixes = 0;
        lastSensorAt = 0;
        lastShakeAt = 0;
        sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        Sensor accel = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (accel != null) sm.registerListener(this, accel, SensorManager.SENSOR_DELAY_UI);
        // Steps come from the phone's own step sensor; without it (or its permission) steps are shown as unavailable.
        Sensor stepSensor = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
        boolean stepPerm = Build.VERSION.SDK_INT < 29
                || checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED;
        stepsAvail = stepSensor != null && stepPerm;
        if (stepsAvail) sm.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_NORMAL);
        if (sVoice) initTts();
        handler.postDelayed(tick, 1000);
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        if (e.sensor.getType() == Sensor.TYPE_STEP_DETECTOR) {
            if (state == REC && !autoPaused) {
                synchronized (LOCK) {
                    steps++;
                }
            }
            return;
        }
        double m = Math.sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]);
        double diff = m - accMean;
        accMean += 0.05 * diff;
        accVar += 0.05 * (diff * diff - accVar);
        long now = SystemClock.elapsedRealtime();
        lastSensorAt = now;
        if (Math.sqrt(accVar) > 0.55) lastShakeAt = now; // walking shakes the phone far more than this
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    private boolean sensorOk(long now) {
        return lastSensorAt != 0 && now - lastSensorAt <= 4000;
    }

    /** True while the phone is being carried by someone walking or running. */
    private boolean bodyMoving(long now) {
        // If the sensor is missing or stops reporting (some phones pause it), trust location alone.
        if (!sensorOk(now)) return true;
        return now - lastShakeAt < 3000;
    }

    /** Prefers the phone's combined GPS + Wi-Fi + mobile network location, falls back to plain GPS. */
    private boolean requestUpdates() {
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                List<String> all = lm.getAllProviders();
                if (all != null && all.contains("fused")) {
                    Api31.request(lm, "fused", getMainExecutor(), this);
                    return true;
                }
            } catch (RuntimeException ignored) {
            }
        }
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper());
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (state == IDLE) return;
            long now = SystemClock.elapsedRealtime();
            long delta = now - lastTick;
            lastTick = now;
            if (state == REC) {
                if (sAutoPause && !autoPaused) {
                    // Stopped: no counted movement for a while and (when the sensor works) the phone is still.
                    long still = now - lastFixAt;
                    boolean stopped = sensorOk(now) ? (still > 8000 && now - lastShakeAt > 5000) : still > 15000;
                    if (stopped && goodFixes >= 4) {
                        autoPaused = true;
                        curSpeed = 0;
                    }
                } else if (!sAutoPause) {
                    autoPaused = false;
                }
                if (!autoPaused) {
                    synchronized (LOCK) {
                        activeMs += delta;
                    }
                }
                if (now - lastFixAt > 6000) curSpeed = 0;
            }
            tickCount++;
            if (tickCount % 5 == 0) {
                getSystemService(NotificationManager.class).notify(NOTIF_ID, buildNotification());
            }
            if (tickCount % 20 == 0) writeSnapshot(TrackService.this);
            handler.postDelayed(this, 1000);
        }
    };

    private Notification buildNotification() {
        double dist;
        long secs;
        synchronized (LOCK) {
            dist = walk + run;
            secs = activeMs / 1000;
        }
        int piFlags = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), piFlags);
        PendingIntent finish = PendingIntent.getService(this, 1,
                new Intent(this, TrackService.class).setAction(ACTION_FINISH), piFlags);
        boolean paused = state == PAUSED;
        PendingIntent toggle = PendingIntent.getService(this, 2,
                new Intent(this, TrackService.class).setAction(paused ? ACTION_RESUME : ACTION_PAUSE), piFlags);
        String text = String.format(Locale.US, "%.2f %s  ·  %d:%02d:%02d", dist / unitM(), sMiles ? "mi" : "km",
                secs / 3600, (secs % 3600) / 60, secs % 60);
        String title = paused ? "Pacevia · Paused" : autoPaused ? "Pacevia · Auto-paused" : "Pacevia · Recording";
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder((Icon) null, paused ? "Resume" : "Pause", toggle).build())
                .addAction(new Notification.Action.Builder((Icon) null, "Finish", finish).build())
                .build();
    }

    @Override
    public void onLocationChanged(Location loc) {
        if (loc == null) return;
        long now = SystemClock.elapsedRealtime();
        // A fix that is already old (replayed after a gap) says nothing about where the phone is now.
        if (now - loc.getElapsedRealtimeNanos() / 1000000L > 15000) return;
        float acc = loc.hasAccuracy() ? loc.getAccuracy() : 999f;
        lastLat = loc.getLatitude();
        lastLon = loc.getLongitude();
        lastAcc = acc;
        lastLocAt = now;
        if (state != REC) {
            anchor = null;
            return;
        }
        if (resetAnchor) {
            resetAnchor = false;
            anchor = null;
        }
        if (acc > sMaxAcc) {
            msg = String.format(Locale.US, "Weak GPS signal (±%d m). It improves in an open area.", Math.round(acc));
            return;
        }
        msg = "";
        // The first few fixes after starting still wander while the position settles.
        if (goodFixes < 4) {
            goodFixes++;
            anchor = null;
            return;
        }
        if (anchor != null && !bodyMoving(now)) {
            // Standing still: follow the position without counting it, so drift never adds up.
            if (acc <= anchor.getAccuracy() + 5) anchor = loc;
            curSpeed = 0;
            return;
        }
        if (anchor == null) {
            anchor = loc;
            lastFixAt = now;
            synchronized (LOCK) {
                addPoint(loc, now);
            }
            return;
        }
        double d = anchor.distanceTo(loc);
        double dt = (loc.getElapsedRealtimeNanos() - anchor.getElapsedRealtimeNanos()) / 1e9;
        if (dt <= 0) return; // duplicate or out-of-order fix
        // Small moves are location noise: the worse the accuracy, the bigger a move must be to count.
        double minStep = Calc.minStep(acc);
        if (d < minStep) return;
        // Without a working motion sensor, the GPS's own speed is the second opinion on small moves.
        if (!sensorOk(now) && loc.hasSpeed() && loc.getSpeed() < 0.2f && d < 2 * minStep) return;
        double sp = d / dt;
        if (sp > MAX_MS || dt > 90) {
            // vehicle, a location jump or a long gap: move on without counting the distance
            anchor = loc;
            lastFixAt = now;
            curSpeed = 0;
            return;
        }
        boolean isRun = Calc.nextIsRun("run".equals(mode), sp * 3.6, sRunKmh, modeVotes);
        curSpeed = sp;
        mode = isRun ? "run" : "walk";
        autoPaused = false;
        String say = null;
        synchronized (LOCK) {
            if (isRun) {
                run += d;
                runMs += (long) (dt * 1000);
            } else {
                walk += d;
                walkMs += (long) (dt * 1000);
            }
            if (sp > maxSp) maxSp = sp;
            if (loc.hasAltitude()) {
                double alt = loc.getAltitude();
                altSmooth = Double.isNaN(altSmooth) ? alt : altSmooth + 0.2 * (alt - altSmooth);
                if (Double.isNaN(altRef)) altRef = altSmooth;
                else if (altSmooth - altRef >= 4) {
                    elev += altSmooth - altRef;
                    altRef = altSmooth;
                } else if (altRef - altSmooth >= 4) altRef = altSmooth;
            }
            addPoint(loc, now);
            double total = walk + run;
            if (sAutoLap && total >= nextLapM) {
                laps.add(new long[]{Math.round(total), activeMs});
                while (nextLapM <= total) nextLapM += unitM();
            }
            if (sVoice && total >= nextVoiceM) {
                say = announcement(nextVoiceM);
                while (nextVoiceM <= total) nextVoiceM += sVoiceEvery * unitM();
            }
        }
        anchor = loc;
        lastFixAt = now;
        if (say != null) speak(say);
    }

    private void addPoint(Location loc, long now) {
        path.add(new double[]{loc.getLatitude(), loc.getLongitude(), "run".equals(mode) ? 1 : 0, activeMs / 1000.0,
                walk + run, loc.hasAltitude() ? loc.getAltitude() : Double.NaN, (now - startEl) / 1000.0});
    }

    // ---------- voice coach ----------

    private String announcement(double metres) {
        StringBuilder b = new StringBuilder();
        double count = metres / unitM();
        String unit = sMiles ? "mile" : "kilometer";
        if (sVDist) {
            b.append(Calc.spokenNumber(count)).append(' ').append(unit).append(Math.abs(count - 1) < 0.001 ? "" : "s").append(" completed. ");
        }
        if (sVTime) b.append("Time ").append(Calc.spokenDuration(activeMs / 1000)).append(". ");
        if (sVPace && walk + run > 0) {
            long paceSecs = Math.round(activeMs / 1000.0 / ((walk + run) / unitM()));
            b.append("Average pace ").append(Calc.spokenDuration(paceSecs)).append(" per ").append(unit).append('.');
        }
        return b.toString().trim();
    }

    private void initTts() {
        if (tts != null) return;
        try {
            tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int status) {
                    if (status != TextToSpeech.SUCCESS || tts == null) return;
                    try {
                        tts.setLanguage(Locale.forLanguageTag(sVLang));
                        tts.setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                            @Override
                            public void onStart(String id) {
                            }

                            @Override
                            public void onDone(String id) {
                                releaseFocus();
                            }

                            @Override
                            public void onError(String id) {
                                releaseFocus();
                            }
                        });
                        ttsReady = true;
                        if (ttsPending != null) {
                            String p = ttsPending;
                            ttsPending = null;
                            speak(p);
                        }
                    } catch (RuntimeException ignored) {
                    }
                }
            });
        } catch (RuntimeException e) {
            tts = null;
        }
    }

    /** Speaks over other audio by lowering it briefly (ducking) instead of stopping it. */
    private void speak(String text) {
        if (text == null || text.isEmpty()) return;
        if (tts == null) {
            ttsPending = text;
            initTts();
            return;
        }
        if (!ttsReady) {
            ttsPending = text;
            return;
        }
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                        .build();
                am.requestAudioFocus(focusReq);
            }
            tts.speak(text, TextToSpeech.QUEUE_ADD, null, "pacevia" + SystemClock.elapsedRealtime());
        } catch (RuntimeException ignored) {
        }
    }

    private void releaseFocus() {
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null && focusReq != null) am.abandonAudioFocusRequest(focusReq);
        } catch (RuntimeException ignored) {
        }
    }

    @Override
    public void onProviderEnabled(String provider) {
        msg = "";
    }

    @Override
    public void onProviderDisabled(String provider) {
        msg = "Turn on Location (GPS) on your phone.";
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(tick);
        if (sm != null) sm.unregisterListener(this);
        try {
            lm.removeUpdates(this);
        } catch (RuntimeException ignored) {
        }
        if (tts != null) {
            try {
                tts.shutdown();
            } catch (RuntimeException ignored) {
            }
            tts = null;
        }
        releaseFocus();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        synchronized (LOCK) {
            if (state != IDLE) {
                if (discard) {
                    clearSession();
                    liveFile(this).delete();
                } else {
                    saveSession(this);
                }
            }
            state = IDLE;
            discard = false;
            autoPaused = false;
            curSpeed = 0;
            msg = "";
        }
        super.onDestroy();
    }
}
