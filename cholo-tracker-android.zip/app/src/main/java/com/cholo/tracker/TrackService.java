package com.cholo.tracker;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

/** Foreground service: reads GPS, adds up walk/run distance, keeps going with the screen off. */
public class TrackService extends Service implements LocationListener {

    static final String ACTION_STOP = "com.cholo.tracker.STOP";
    static final String CHANNEL = "tracking";
    static final int NOTIF_ID = 1;

    static final double RUN_KMH = 7.0;   // faster than this counts as running
    static final double MAX_MS = 8.0;    // faster than this is a vehicle or a GPS jump
    static final double MIN_STEP = 4.0;  // metres; smaller moves are GPS jitter
    static final float MAX_ACC = 35f;    // metres; worse fixes are ignored

    static final Object LOCK = new Object();
    static volatile boolean running = false;
    static volatile double curSpeed = 0;
    static volatile String mode = "walk";
    static volatile String msg = "";
    static final ArrayList<double[]> path = new ArrayList<>();
    private static JSONObject store;

    private LocationManager lm;
    private Handler handler;
    private PowerManager.WakeLock wakeLock;
    private Location last;
    private long lastFixAt = 0;
    private long lastTick = 0;
    private long msAcc = 0;
    private int tickCount = 0;

    // ---------- shared data (also used by MainActivity) ----------

    static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("cholo", Context.MODE_PRIVATE);
    }

    static JSONObject store(Context c) {
        synchronized (LOCK) {
            if (store == null) {
                try {
                    store = new JSONObject(prefs(c).getString("store", "{}"));
                } catch (JSONException e) {
                    store = new JSONObject();
                }
            }
            return store;
        }
    }

    static void persist(Context c) {
        synchronized (LOCK) {
            prefs(c).edit().putString("store", store(c).toString()).apply();
        }
    }

    static String key(int daysAgo) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -daysAgo);
        return String.format(Locale.US, "%04d-%02d-%02d",
                cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH));
    }

    static JSONObject day(Context c, String k) throws JSONException {
        synchronized (LOCK) {
            JSONObject s = store(c);
            JSONObject days = s.optJSONObject("days");
            if (days == null) {
                days = new JSONObject();
                s.put("days", days);
            }
            JSONObject d = days.optJSONObject(k);
            if (d == null) {
                d = new JSONObject();
                d.put("walk", 0);
                d.put("run", 0);
                d.put("secs", 0);
                days.put(k, d);
            }
            return d;
        }
    }

    static void setGoal(Context c, int goal) {
        synchronized (LOCK) {
            try {
                store(c).put("goal", Math.max(1, Math.min(50, goal)));
            } catch (JSONException ignored) {
            }
            persist(c);
        }
    }

    static void resetToday(Context c) {
        synchronized (LOCK) {
            try {
                JSONObject d = day(c, key(0));
                d.put("walk", 0);
                d.put("run", 0);
                d.put("secs", 0);
            } catch (JSONException ignored) {
            }
            path.clear();
            persist(c);
        }
    }

    static String stateJson(Context c) {
        synchronized (LOCK) {
            try {
                JSONObject o = new JSONObject();
                o.put("tracking", running);
                o.put("speed", running ? curSpeed : 0);
                o.put("mode", mode);
                o.put("msg", msg);
                o.put("goal", store(c).optInt("goal", 5));
                JSONArray week = new JSONArray();
                for (int i = 6; i >= 0; i--) {
                    Calendar cal = Calendar.getInstance();
                    cal.add(Calendar.DAY_OF_YEAR, -i);
                    JSONObject d = day(c, key(i));
                    JSONObject w = new JSONObject();
                    w.put("dow", cal.get(Calendar.DAY_OF_WEEK) - 1);
                    w.put("date", cal.get(Calendar.DAY_OF_MONTH));
                    w.put("month", cal.get(Calendar.MONTH));
                    w.put("walk", d.optDouble("walk", 0));
                    w.put("run", d.optDouble("run", 0));
                    w.put("secs", d.optLong("secs", 0));
                    week.put(w);
                }
                o.put("week", week);
                JSONArray p = new JSONArray();
                for (double[] pt : path) {
                    JSONArray a = new JSONArray();
                    a.put(pt[0]);
                    a.put(pt[1]);
                    a.put(pt[2]);
                    p.put(a);
                }
                o.put("path", p);
                return o.toString();
            } catch (JSONException e) {
                return "{}";
            }
        }
    }

    private static void addPoint(double lat, double lon, boolean run) {
        synchronized (LOCK) {
            path.add(new double[]{lat, lon, run ? 1 : 0});
            if (path.size() > 3000) {
                // thin out old points so the list never grows without limit
                ArrayList<double[]> keep = new ArrayList<>();
                for (int i = 0; i < path.size(); i++) {
                    if (i % 2 == 0 || i > path.size() - 200) keep.add(path.get(i));
                }
                path.clear();
                path.addAll(keep);
            }
        }
    }

    // ---------- service ----------

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        handler = new Handler(Looper.getMainLooper());
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Tracking", NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        nm.createNotificationChannel(ch);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!running) begin();
        return START_NOT_STICKY;
    }

    private void begin() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            } else {
                startForeground(NOTIF_ID, buildNotification());
            }
        } catch (RuntimeException e) {
            msg = "Tracking chalu kora gelo na. Location permission din.";
            stopSelf();
            return;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            msg = "Location permission deya hoyni.";
            stopSelf();
            return;
        }
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper());
        } catch (SecurityException | IllegalArgumentException e) {
            msg = "Ei phone e GPS pawa jacche na.";
            stopSelf();
            return;
        }
        synchronized (LOCK) {
            path.clear();
        }
        last = null;
        curSpeed = 0;
        mode = "walk";
        msg = lm.isProviderEnabled(LocationManager.GPS_PROVIDER) ? "" : "Phone er Location (GPS) on korun.";
        running = true;

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "cholo:track");
        wakeLock.setReferenceCounted(false);
        wakeLock.acquire();

        lastTick = SystemClock.elapsedRealtime();
        lastFixAt = lastTick;
        msAcc = 0;
        handler.postDelayed(tick, 1000);
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            long now = SystemClock.elapsedRealtime();
            msAcc += now - lastTick;
            lastTick = now;
            long add = msAcc / 1000;
            msAcc -= add * 1000;
            if (add > 0) {
                synchronized (LOCK) {
                    try {
                        JSONObject d = day(TrackService.this, key(0));
                        d.put("secs", d.optLong("secs", 0) + add);
                    } catch (JSONException ignored) {
                    }
                }
            }
            if (now - lastFixAt > 6000) curSpeed = 0;
            tickCount++;
            if (tickCount % 10 == 0) persist(TrackService.this);
            if (tickCount % 5 == 0) {
                getSystemService(NotificationManager.class).notify(NOTIF_ID, buildNotification());
            }
            handler.postDelayed(this, 1000);
        }
    };

    private Notification buildNotification() {
        double total = 0;
        synchronized (LOCK) {
            try {
                JSONObject d = day(this, key(0));
                total = d.optDouble("walk", 0) + d.optDouble("run", 0);
            } catch (JSONException ignored) {
            }
        }
        int piFlags = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), piFlags);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, TrackService.class).setAction(ACTION_STOP), piFlags);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Cholo Tracker cholche")
                .setContentText(String.format(Locale.US, "Aaj mot %.2f km", total / 1000.0))
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder((Icon) null, "Stop", stop).build())
                .build();
    }

    @Override
    public void onLocationChanged(Location loc) {
        if (!running || loc == null) return;
        if (!loc.hasAccuracy() || loc.getAccuracy() > MAX_ACC) {
            msg = "GPS signal durbol. Khola jaygay gele thik hobe.";
            return;
        }
        msg = "";
        long now = SystemClock.elapsedRealtime();
        if (last == null) {
            last = loc;
            lastFixAt = now;
            addPoint(loc.getLatitude(), loc.getLongitude(), false);
            return;
        }
        double d = last.distanceTo(loc);
        double dt = (loc.getElapsedRealtimeNanos() - last.getElapsedRealtimeNanos()) / 1e9;
        if (dt <= 0) return;
        if (d < MIN_STEP) return; // standing still or jitter; keep the old anchor point
        double sp = d / dt;
        if (sp > MAX_MS || dt > 60) {
            // vehicle, GPS jump or a long gap: move the anchor without counting the distance
            last = loc;
            lastFixAt = now;
            curSpeed = 0;
            return;
        }
        boolean run = sp * 3.6 >= RUN_KMH;
        curSpeed = sp;
        mode = run ? "run" : "walk";
        synchronized (LOCK) {
            try {
                JSONObject day = day(this, key(0));
                String k = run ? "run" : "walk";
                day.put(k, day.optDouble(k, 0) + d);
            } catch (JSONException ignored) {
            }
        }
        addPoint(loc.getLatitude(), loc.getLongitude(), run);
        last = loc;
        lastFixAt = now;
    }

    @Override
    public void onProviderEnabled(String provider) {
        msg = "";
    }

    @Override
    public void onProviderDisabled(String provider) {
        msg = "Phone er Location (GPS) on korun.";
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    @Override
    public void onDestroy() {
        running = false;
        curSpeed = 0;
        handler.removeCallbacks(tick);
        try {
            lm.removeUpdates(this);
        } catch (RuntimeException ignored) {
        }
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        persist(this);
        super.onDestroy();
    }
}
