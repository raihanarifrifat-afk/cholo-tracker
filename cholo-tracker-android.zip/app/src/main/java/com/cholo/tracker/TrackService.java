package com.cholo.tracker;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationRequest;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executor;

/**
 * Foreground service that records one activity (a walk or run): reads location,
 * adds up distance and moving time, keeps going with the screen off, and saves
 * the finished activity with its route.
 */
public class TrackService extends Service implements LocationListener, SensorEventListener {

    static final String ACTION_FINISH = "com.cholo.tracker.FINISH";
    static final String CHANNEL = "tracking";
    static final int NOTIF_ID = 1;

    static final int IDLE = 0, REC = 1, PAUSED = 2;

    static final double RUN_KMH = 7.0;   // faster than this counts as running
    static final double MAX_MS = 8.0;    // faster than this is a vehicle or a location jump
    static final float MAX_ACC = 35f;    // metres; worse fixes are shown on the map but not counted
    static final double MIN_SAVE_M = 20; // shorter activities are not saved
    static final int MAX_SAVED_POINTS = 600;

    static final Object LOCK = new Object();
    static volatile int state = IDLE;
    static volatile boolean discard = false;
    static volatile boolean resetAnchor = false;
    static volatile double curSpeed = 0;
    static volatile String mode = "walk";
    static volatile String msg = "";
    static volatile String mapMsg = "";
    static volatile double lastLat = Double.NaN, lastLon = Double.NaN;
    static volatile float lastAcc = -1;

    // the activity being recorded (guarded by LOCK)
    static long sid = 0;
    static long activeMs = 0;
    static double walk = 0, run = 0;
    static final ArrayList<double[]> path = new ArrayList<>();

    private LocationManager lm;
    private Handler handler;
    private PowerManager.WakeLock wakeLock;
    private Location anchor;
    private long lastFixAt = 0;
    private long lastTick = 0;
    private int tickCount = 0;

    // Movement check from the phone's motion sensor, so standing still never adds distance.
    private SensorManager sm;
    private double accMean = 9.8, accVar = 0;
    private long lastSensorAt = 0, lastShakeAt = 0;
    private int goodFixes = 0;

    // ---------- storage ----------

    static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("cholo", Context.MODE_PRIVATE);
    }

    static File liveFile(Context c) {
        return new File(c.getApplicationContext().getFilesDir(), "live.json");
    }

    static File pathFile(Context c, long id) {
        return new File(c.getApplicationContext().getFilesDir(), "act_" + id + ".json");
    }

    static String readFile(File f) {
        if (!f.exists()) return null;
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] b = new byte[(int) f.length()];
            int off = 0, n;
            while (off < b.length && (n = in.read(b, off, b.length - off)) > 0) off += n;
            return new String(b, 0, off, StandardCharsets.UTF_8);
        } catch (IOException e) {
            return null;
        }
    }

    static void writeFile(File f, String s) {
        try (FileOutputStream o = new FileOutputStream(f)) {
            o.write(s.getBytes(StandardCharsets.UTF_8));
        } catch (IOException ignored) {
        }
    }

    static String activitiesJson(Context c) {
        synchronized (LOCK) {
            return prefs(c).getString("acts", "[]");
        }
    }

    static String activityJson(Context c, long id) {
        synchronized (LOCK) {
            try {
                JSONArray arr = new JSONArray(activitiesJson(c));
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject a = arr.getJSONObject(i);
                    if (a.optLong("id") == id) {
                        String p = readFile(pathFile(c, id));
                        a.put("path", p == null ? new JSONArray() : new JSONArray(p));
                        return a.toString();
                    }
                }
            } catch (JSONException ignored) {
            }
            return "null";
        }
    }

    static void deleteActivity(Context c, long id) {
        synchronized (LOCK) {
            try {
                JSONArray arr = new JSONArray(activitiesJson(c));
                JSONArray out = new JSONArray();
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject a = arr.getJSONObject(i);
                    if (a.optLong("id") != id) out.put(a);
                }
                prefs(c).edit().putString("acts", out.toString()).apply();
            } catch (JSONException ignored) {
            }
            pathFile(c, id).delete();
        }
    }

    static void setGoal(Context c, int goal) {
        prefs(c).edit().putInt("goal", Math.max(1, Math.min(50, goal))).apply();
    }

    private static JSONArray pathArray(int maxPoints) throws JSONException {
        JSONArray p = new JSONArray();
        int n = path.size();
        int step = (maxPoints > 0 && n > maxPoints) ? (int) Math.ceil(n / (double) maxPoints) : 1;
        for (int i = 0; i < n; i++) {
            if (i % step != 0 && i != n - 1) continue;
            double[] pt = path.get(i);
            JSONArray a = new JSONArray();
            a.put(Math.round(pt[0] * 1e6) / 1e6);
            a.put(Math.round(pt[1] * 1e6) / 1e6);
            a.put((int) pt[2]);
            p.put(a);
        }
        return p;
    }

    private static String nameFor(long startMs, boolean isRun) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(startMs);
        int h = cal.get(Calendar.HOUR_OF_DAY);
        String part = h < 5 ? "Night" : h < 12 ? "Morning" : h < 17 ? "Afternoon" : h < 20 ? "Evening" : "Night";
        return part + (isRun ? " Run" : " Walk");
    }

    /** Saves the current session as an activity. Returns false if it was too short to keep. */
    static boolean saveSession(Context c) {
        synchronized (LOCK) {
            boolean saved = false;
            double dist = walk + run;
            if (sid > 0 && dist >= MIN_SAVE_M) {
                try {
                    JSONObject a = new JSONObject();
                    a.put("id", sid);
                    a.put("name", nameFor(sid, run > walk));
                    a.put("start", sid);
                    a.put("secs", activeMs / 1000);
                    a.put("dist", Math.round(dist));
                    a.put("walk", Math.round(walk));
                    a.put("run", Math.round(run));
                    writeFile(pathFile(c, sid), pathArray(MAX_SAVED_POINTS).toString());
                    JSONArray arr = new JSONArray(activitiesJson(c));
                    JSONArray out = new JSONArray();
                    out.put(a);
                    for (int i = 0; i < arr.length(); i++) {
                        if (arr.getJSONObject(i).optLong("id") != sid) out.put(arr.get(i));
                    }
                    prefs(c).edit().putString("acts", out.toString()).apply();
                    saved = true;
                } catch (JSONException ignored) {
                }
            }
            clearSession();
            liveFile(c).delete();
            return saved;
        }
    }

    static void clearSession() {
        synchronized (LOCK) {
            sid = 0;
            activeMs = 0;
            walk = 0;
            run = 0;
            path.clear();
        }
    }

    private static void writeSnapshot(Context c) {
        synchronized (LOCK) {
            try {
                JSONObject o = new JSONObject();
                o.put("sid", sid);
                o.put("ms", activeMs);
                o.put("walk", walk);
                o.put("run", run);
                o.put("path", pathArray(0));
                writeFile(liveFile(c), o.toString());
            } catch (JSONException ignored) {
            }
        }
    }

    /** If the app was killed in the middle of a recording, save what was recorded. */
    static void recover(Context c) {
        synchronized (LOCK) {
            if (state != IDLE) return;
            String s = readFile(liveFile(c));
            if (s == null) return;
            try {
                JSONObject o = new JSONObject(s);
                clearSession();
                sid = o.optLong("sid");
                activeMs = o.optLong("ms");
                walk = o.optDouble("walk", 0);
                run = o.optDouble("run", 0);
                JSONArray p = o.optJSONArray("path");
                if (p != null) {
                    for (int i = 0; i < p.length(); i++) {
                        JSONArray a = p.getJSONArray(i);
                        path.add(new double[]{a.getDouble(0), a.getDouble(1), a.getInt(2)});
                    }
                }
                saveSession(c);
            } catch (JSONException e) {
                clearSession();
                liveFile(c).delete();
            }
        }
    }

    // ---------- state for the UI ----------

    static String stateJson(Context c) {
        synchronized (LOCK) {
            try {
                if (Double.isNaN(lastLat)) lastKnown(c);
                JSONObject o = new JSONObject();
                o.put("state", state == REC ? "rec" : state == PAUSED ? "paused" : "idle");
                o.put("sid", sid);
                o.put("secs", activeMs / 1000);
                o.put("walk", walk);
                o.put("run", run);
                o.put("dist", walk + run);
                o.put("speed", state == REC ? curSpeed : 0);
                o.put("mode", mode);
                o.put("msg", msg);
                o.put("mapMsg", mapMsg);
                o.put("n", path.size());
                o.put("goal", prefs(c).getInt("goal", 5));
                o.put("acc", lastAcc);
                if (!Double.isNaN(lastLat)) {
                    o.put("lat", lastLat);
                    o.put("lon", lastLon);
                }
                return o.toString();
            } catch (JSONException e) {
                return "{}";
            }
        }
    }

    static String pathJson(int from) {
        synchronized (LOCK) {
            JSONArray p = new JSONArray();
            try {
                for (int i = Math.max(0, from); i < path.size(); i++) {
                    double[] pt = path.get(i);
                    JSONArray a = new JSONArray();
                    a.put(pt[0]);
                    a.put(pt[1]);
                    a.put((int) pt[2]);
                    p.put(a);
                }
            } catch (JSONException ignored) {
            }
            return p.toString();
        }
    }

    private static void lastKnown(Context c) {
        if (c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        try {
            LocationManager m = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
            Location best = null;
            for (String p : m.getAllProviders()) {
                Location l = m.getLastKnownLocation(p);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            }
            if (best != null) {
                lastLat = best.getLatitude();
                lastLon = best.getLongitude();
                lastAcc = best.hasAccuracy() ? best.getAccuracy() : -1;
            }
        } catch (RuntimeException ignored) {
        }
    }

    static void setPaused(boolean paused) {
        synchronized (LOCK) {
            if (state == IDLE) return;
            state = paused ? PAUSED : REC;
            resetAnchor = true;
            curSpeed = 0;
        }
    }

    // ---------- service ----------

    /** Kept in its own class so older Android versions never load LocationRequest. */
    private static final class Api31 {
        static void request(LocationManager lm, String provider, Executor ex, LocationListener l) {
            LocationRequest r = new LocationRequest.Builder(1000L)
                    .setQuality(LocationRequest.QUALITY_HIGH_ACCURACY)
                    .setMinUpdateIntervalMillis(1000L)
                    .build();
            lm.requestLocationUpdates(provider, r, ex, l);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        handler = new Handler(Looper.getMainLooper());
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Tracking", NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        nm.createNotificationChannel(ch);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_FINISH.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (state == IDLE) begin();
        return START_NOT_STICKY;
    }

    private void begin() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            } else {
                startForeground(NOTIF_ID, buildNotification());
            }
        } catch (RuntimeException e) {
            msg = "Could not start tracking. Please allow Location permission.";
            stopSelf();
            return;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            msg = "Location permission was not granted.";
            stopSelf();
            return;
        }
        if (!requestUpdates()) {
            msg = "Location is not available on this phone.";
            stopSelf();
            return;
        }
        synchronized (LOCK) {
            clearSession();
            sid = System.currentTimeMillis();
            state = REC;
        }
        discard = false;
        resetAnchor = false;
        anchor = null;
        curSpeed = 0;
        mode = "walk";
        msg = lm.isProviderEnabled(LocationManager.GPS_PROVIDER) ? "" : "Turn on Location (GPS) on your phone.";

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "cholo:track");
        wakeLock.setReferenceCounted(false);
        wakeLock.acquire();

        lastTick = SystemClock.elapsedRealtime();
        lastFixAt = lastTick;
        goodFixes = 0;
        lastSensorAt = 0;
        lastShakeAt = 0;
        sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        Sensor accel = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (accel != null) sm.registerListener(this, accel, SensorManager.SENSOR_DELAY_UI);
        handler.postDelayed(tick, 1000);
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        double m = Math.sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]);
        double diff = m - accMean;
        accMean += 0.05 * diff;
        accVar += 0.05 * (diff * diff - accVar);
        long now = SystemClock.elapsedRealtime();
        lastSensorAt = now;
        if (Math.sqrt(accVar) > 0.55) lastShakeAt = now; // walking shakes the phone far more than this
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    /** True while the phone is being carried by someone walking or running. */
    private boolean bodyMoving(long now) {
        // If the sensor is missing or stops reporting (some phones pause it), trust location alone.
        if (lastSensorAt == 0 || now - lastSensorAt > 4000) return true;
        return now - lastShakeAt < 3000;
    }

    /** Prefers the phone's combined GPS + Wi-Fi + mobile network location, falls back to plain GPS. */
    private boolean requestUpdates() {
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                List<String> all = lm.getAllProviders();
                if (all != null && all.contains("fused")) {
                    Api31.request(lm, "fused", getMainExecutor(), this);
                    return true;
                }
            } catch (RuntimeException ignored) {
            }
        }
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper());
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (state == IDLE) return;
            long now = SystemClock.elapsedRealtime();
            long delta = now - lastTick;
            lastTick = now;
            if (state == REC) {
                synchronized (LOCK) {
                    activeMs += delta;
                }
                if (now - lastFixAt > 6000) curSpeed = 0;
            }
            tickCount++;
            if (tickCount % 5 == 0) {
                getSystemService(NotificationManager.class).notify(NOTIF_ID, buildNotification());
            }
            if (tickCount % 20 == 0) writeSnapshot(TrackService.this);
            handler.postDelayed(this, 1000);
        }
    };

    private Notification buildNotification() {
        double dist;
        long secs;
        synchronized (LOCK) {
            dist = walk + run;
            secs = activeMs / 1000;
        }
        int piFlags = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), piFlags);
        PendingIntent finish = PendingIntent.getService(this, 1,
                new Intent(this, TrackService.class).setAction(ACTION_FINISH), piFlags);
        String text = String.format(Locale.US, "%.2f km  ·  %d:%02d:%02d", dist / 1000.0,
                secs / 3600, (secs % 3600) / 60, secs % 60);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(state == PAUSED ? "Cholo Tracker (paused)" : "Cholo Tracker is recording")
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder((Icon) null, "Finish", finish).build())
                .build();
    }

    @Override
    public void onLocationChanged(Location loc) {
        if (loc == null) return;
        float acc = loc.hasAccuracy() ? loc.getAccuracy() : 999f;
        lastLat = loc.getLatitude();
        lastLon = loc.getLongitude();
        lastAcc = acc;
        if (state != REC) {
            anchor = null;
            return;
        }
        if (resetAnchor) {
            resetAnchor = false;
            anchor = null;
        }
        if (acc > MAX_ACC) {
            msg = String.format(Locale.US, "Weak signal (±%d m). It improves in an open area.", Math.round(acc));
            return;
        }
        msg = "";
        long now = SystemClock.elapsedRealtime();
        // The first few fixes after starting still wander while the position settles.
        if (goodFixes < 4) {
            goodFixes++;
            anchor = null;
            return;
        }
        if (anchor != null && !bodyMoving(now)) {
            // Standing still: follow the position without counting it, so drift never adds up.
            if (acc <= anchor.getAccuracy() + 5) anchor = loc;
            curSpeed = 0;
            return;
        }
        if (anchor == null) {
            anchor = loc;
            lastFixAt = now;
            synchronized (LOCK) {
                path.add(new double[]{loc.getLatitude(), loc.getLongitude(), "run".equals(mode) ? 1 : 0});
            }
            return;
        }
        double d = anchor.distanceTo(loc);
        double dt = (loc.getElapsedRealtimeNanos() - anchor.getElapsedRealtimeNanos()) / 1e9;
        if (dt <= 0) return;
        // Small moves are location noise: the worse the accuracy, the bigger a move must be to count.
        double minStep = Math.max(5.0, Math.min(acc * 0.6, 15.0));
        if (d < minStep) return;
        double sp = d / dt;
        if (sp > MAX_MS || dt > 90) {
            // vehicle, a location jump or a long gap: move on without counting the distance
            anchor = loc;
            lastFixAt = now;
            curSpeed = 0;
            return;
        }
        boolean isRun = sp * 3.6 >= RUN_KMH;
        curSpeed = sp;
        mode = isRun ? "run" : "walk";
        synchronized (LOCK) {
            if (isRun) run += d;
            else walk += d;
            path.add(new double[]{loc.getLatitude(), loc.getLongitude(), isRun ? 1 : 0});
        }
        anchor = loc;
        lastFixAt = now;
    }

    @Override
    public void onProviderEnabled(String provider) {
        msg = "";
    }

    @Override
    public void onProviderDisabled(String provider) {
        msg = "Turn on Location (GPS) on your phone.";
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(tick);
        if (sm != null) sm.unregisterListener(this);
        try {
            lm.removeUpdates(this);
        } catch (RuntimeException ignored) {
        }
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        synchronized (LOCK) {
            if (state != IDLE) {
                if (discard) {
                    clearSession();
                    liveFile(this).delete();
                } else {
                    saveSession(this);
                }
            }
            state = IDLE;
            discard = false;
            curSpeed = 0;
            msg = "";
        }
        super.onDestroy();
    }
}
