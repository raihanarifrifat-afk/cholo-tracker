package com.cholo.tracker;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/** Shows the UI (assets/index.html) and passes button taps to TrackService. */
public class MainActivity extends Activity {

    private static final int REQ_PERMS = 1, REQ_SAVE = 2, REQ_OPEN = 3;
    private static final int BG = 0xFF0B1117, BG_LIGHT = 0xFFF3F6F8;
    private static final long TILE_MAX_AGE_MS = 7L * 24 * 3600 * 1000;
    private WebView web;
    private boolean askedExtras = false;
    private byte[] pendingSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        TrackService.applySettings(this);
        TrackService.recover(this);

        web = new WebView(this);
        web.setBackgroundColor(BG);
        web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        // Follow the phone's font size setting, within what the layout can hold.
        float scale = getResources().getConfiguration().fontScale;
        s.setTextZoom(Math.round(Math.max(0.9f, Math.min(1.3f, scale)) * 100));
        s.setUserAgentString(s.getUserAgentString() + " Pacevia/" + versionName());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return true; // the app is a single page; never navigate away from it
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String host = request.getUrl().getHost();
                if (host == null) return null;
                boolean osm = host.endsWith("tile.openstreetmap.org") || host.endsWith("tile.opentopomap.org");
                if (osm || host.endsWith("server.arcgisonline.com")) {
                    // Only the OpenStreetMap-based tiles are kept on the phone (their policy asks apps to cache).
                    return loadTile(request.getUrl().toString(), host + request.getUrl().getPath(), osm);
                }
                return null;
            }
        });
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException | RuntimeException e) {
            return "";
        }
    }

    /** Tells the page that something it asked for has finished. */
    private void notifyPage(final String type, final String detail) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web == null) return;
                web.evaluateJavascript("window.onNative&&window.onNative(" + JSONObject.quote(type) + ","
                        + JSONObject.quote(detail == null ? "" : detail) + ")", null);
            }
        });
    }

    private class Bridge {
        @JavascriptInterface
        public String getState() {
            return TrackService.stateJson(MainActivity.this);
        }

        @JavascriptInterface
        public String getPath(int from) {
            return TrackService.pathJson(from);
        }

        @JavascriptInterface
        public String getActivities() {
            return TrackService.activitiesJson(MainActivity.this);
        }

        @JavascriptInterface
        public String getActivity(String id) {
            try {
                return TrackService.activityJson(MainActivity.this, Long.parseLong(id));
            } catch (NumberFormatException e) {
                return "null";
            }
        }

        @JavascriptInterface
        public void deleteActivity(String id) {
            try {
                TrackService.deleteActivity(MainActivity.this, Long.parseLong(id));
            } catch (NumberFormatException ignored) {
            }
        }

        @JavascriptInterface
        public void updateActivity(String id, String name, String type) {
            try {
                TrackService.updateActivity(MainActivity.this, Long.parseLong(id), name, type);
            } catch (NumberFormatException ignored) {
            }
        }

        @JavascriptInterface
        public void setGoal(int goal) {
            TrackService.setGoal(MainActivity.this, goal);
        }

        @JavascriptInterface
        public String getSettings() {
            return TrackService.settingsJson(MainActivity.this);
        }

        @JavascriptInterface
        public void setSettings(String json) {
            TrackService.setSettings(MainActivity.this, json);
        }

        @JavascriptInterface
        public String version() {
            return versionName();
        }

        @JavascriptInterface
        public void start() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    beginTracking();
                }
            });
        }

        @JavascriptInterface
        public void pause() {
            TrackService.setPaused(true);
        }

        @JavascriptInterface
        public void resume() {
            TrackService.setPaused(false);
        }

        @JavascriptInterface
        public void lap() {
            TrackService.addLap();
        }

        @JavascriptInterface
        public void finish() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    stopService(new Intent(MainActivity.this, TrackService.class));
                }
            });
        }

        @JavascriptInterface
        public void discard() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    TrackService.discard = true;
                    stopService(new Intent(MainActivity.this, TrackService.class));
                }
            });
        }

        /** Lets the user pick where to save a file (GPX, CSV, image). data is text, or Base64 when b64 is true. */
        @JavascriptInterface
        public void saveFile(final String name, final String mime, String data, boolean b64) {
            try {
                final byte[] bytes = b64 ? Base64.decode(data, Base64.DEFAULT) : data.getBytes(StandardCharsets.UTF_8);
                askWhereToSave(name, mime, bytes);
            } catch (RuntimeException e) {
                notifyPage("error", "Could not prepare the file.");
            }
        }

        @JavascriptInterface
        public void backup(boolean zip) {
            try {
                byte[] bytes = Backup.bytes(MainActivity.this, zip);
                String day = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(new java.util.Date());
                askWhereToSave("pacevia-backup-" + day + (zip ? ".zip" : ".json"), zip ? "application/zip" : "application/json", bytes);
            } catch (Exception e) {
                notifyPage("error", "Could not create the backup.");
            }
        }

        @JavascriptInterface
        public void restore() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("*/*");
                        startActivityForResult(i, REQ_OPEN);
                    } catch (RuntimeException e) {
                        notifyPage("error", "No file picker is available on this phone.");
                    }
                }
            });
        }

        @JavascriptInterface
        public void clearAll() {
            TrackService.clearAll(MainActivity.this);
        }

        @JavascriptInterface
        public void share(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("text/plain");
                        i.putExtra(Intent.EXTRA_TEXT, text);
                        startActivity(Intent.createChooser(i, "Share workout"));
                    } catch (RuntimeException ignored) {
                    }
                }
            });
        }

        /** Matches the system bars to the page's light or dark theme. */
        @JavascriptInterface
        public void setBars(final boolean light) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    int c = light ? BG_LIGHT : BG;
                    getWindow().setStatusBarColor(c);
                    getWindow().setNavigationBarColor(c);
                    View d = getWindow().getDecorView();
                    int f = d.getSystemUiVisibility();
                    int lightFlags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    d.setSystemUiVisibility(light ? (f | lightFlags) : (f & ~lightFlags));
                    if (web != null) web.setBackgroundColor(c);
                }
            });
        }
    }

    private void askWhereToSave(final String name, final String mime, final byte[] bytes) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    pendingSave = bytes;
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType(mime);
                    i.putExtra(Intent.EXTRA_TITLE, name);
                    startActivityForResult(i, REQ_SAVE);
                } catch (RuntimeException e) {
                    pendingSave = null;
                    notifyPage("error", "No file picker is available on this phone.");
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        final Uri uri = (resultCode == RESULT_OK && data != null) ? data.getData() : null;
        if (requestCode == REQ_SAVE) {
            final byte[] bytes = pendingSave;
            pendingSave = null;
            if (uri == null || bytes == null) return;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try (OutputStream o = getContentResolver().openOutputStream(uri)) {
                        if (o == null) throw new IOException("no stream");
                        o.write(bytes);
                        notifyPage("saved", "");
                    } catch (IOException | RuntimeException e) {
                        notifyPage("error", "The file could not be saved.");
                    }
                }
            }).start();
        } else if (requestCode == REQ_OPEN) {
            if (uri == null) return;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try (InputStream in = getContentResolver().openInputStream(uri)) {
                        if (in == null) throw new IOException("no stream");
                        ByteArrayOutputStream buf = new ByteArrayOutputStream();
                        byte[] b = new byte[8192];
                        int n;
                        while ((n = in.read(b)) > 0) {
                            buf.write(b, 0, n);
                            if (buf.size() > 80 * 1024 * 1024) throw new IOException("too large");
                        }
                        int added = Backup.restore(MainActivity.this, buf.toByteArray());
                        if (added < 0) notifyPage("error", "That file is not a Pacevia backup.");
                        else notifyPage("restored", String.valueOf(added));
                    } catch (IOException | RuntimeException e) {
                        notifyPage("error", "The file could not be read.");
                    }
                }
            }).start();
        }
    }

    /**
     * Map tiles are fetched here, not by the page: the map server refuses requests that do not
     * identify the app. OpenStreetMap-based tiles are kept for a week so each one is downloaded rarely.
     */
    private WebResourceResponse loadTile(String url, String path, boolean cache) {
        try {
            File f = null;
            if (cache) {
                File dir = new File(getCacheDir(), "tiles");
                if (!dir.exists()) dir.mkdirs();
                f = new File(dir, String.valueOf(path).replaceAll("[^0-9a-zA-Z.]", "_"));
                if (f.exists() && f.length() > 0 && System.currentTimeMillis() - f.lastModified() < TILE_MAX_AGE_MS) {
                    return new WebResourceResponse("image/png", null, new FileInputStream(f));
                }
            }
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            c.setRequestProperty("User-Agent", "Pacevia/" + versionName() + " (Android app; com.cholo.tracker)");
            int code = c.getResponseCode();
            if (code != 200) {
                c.disconnect();
                if (f != null && f.exists() && f.length() > 0) {
                    return new WebResourceResponse("image/png", null, new FileInputStream(f)); // stale beats blank
                }
                TrackService.mapMsg = "Map server answered " + code;
                return new WebResourceResponse("image/png", null, 404, "Not Found", null, new ByteArrayInputStream(new byte[0]));
            }
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            try (InputStream in = c.getInputStream()) {
                byte[] b = new byte[8192];
                int n;
                while ((n = in.read(b)) > 0) buf.write(b, 0, n);
            }
            c.disconnect();
            byte[] data = buf.toByteArray();
            if (f != null) {
                try (FileOutputStream o = new FileOutputStream(f)) {
                    o.write(data);
                }
            }
            TrackService.mapMsg = "";
            return new WebResourceResponse("image/png", null, new ByteArrayInputStream(data));
        } catch (IOException | RuntimeException e) {
            TrackService.mapMsg = "Map needs internet";
            return new WebResourceResponse("image/png", null, 404, "Not Found", null, new ByteArrayInputStream(new byte[0]));
        }
    }

    private boolean granted(String perm) {
        return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    private void beginTracking() {
        if (TrackService.state != TrackService.IDLE) return;
        ArrayList<String> extras = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
            extras.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (Build.VERSION.SDK_INT >= 29 && !granted(Manifest.permission.ACTIVITY_RECOGNITION)) {
            extras.add(Manifest.permission.ACTIVITY_RECOGNITION); // only used to count steps; optional
        }
        if (!granted(Manifest.permission.ACCESS_FINE_LOCATION)) {
            ArrayList<String> perms = new ArrayList<>();
            perms.add(Manifest.permission.ACCESS_FINE_LOCATION);
            perms.add(Manifest.permission.ACCESS_COARSE_LOCATION);
            perms.addAll(extras);
            askedExtras = true;
            requestPermissions(perms.toArray(new String[0]), REQ_PERMS);
            return;
        }
        // Notifications and step counting are asked for once; recording works without them.
        if (!extras.isEmpty() && !askedExtras) {
            askedExtras = true;
            requestPermissions(extras.toArray(new String[0]), REQ_PERMS);
            return;
        }
        TrackService.msg = "";
        startForegroundService(new Intent(this, TrackService.class));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_PERMS) return;
        askedExtras = true;
        if (granted(Manifest.permission.ACCESS_FINE_LOCATION)) {
            beginTracking();
        } else {
            TrackService.msg = "Location permission was not granted. Go to Settings > Apps > Pacevia > Permissions, "
                    + "allow \"Precise\" Location, then tap Start again.";
        }
    }

    @Override
    public void onBackPressed() {
        // let the page close an open screen first; it calls back with "exit" if there is nothing to close
        web.evaluateJavascript("window.onBack ? window.onBack() : 'exit'", new android.webkit.ValueCallback<String>() {
            @Override
            public void onReceiveValue(String v) {
                if (v == null || v.contains("exit")) moveTaskToBack(true);
            }
        });
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
