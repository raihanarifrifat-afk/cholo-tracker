package com.cholo.tracker;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/** Shows the UI (assets/index.html) and passes button taps to TrackService. */
public class MainActivity extends Activity {

    private static final int REQ_PERMS = 1;
    private static final int BG = 0xFF15122B;
    private WebView web;
    private boolean askedNotif = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        TrackService.recover(this);

        web = new WebView(this);
        web.setBackgroundColor(BG);
        web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100);
        s.setUserAgentString(s.getUserAgentString() + " CholoTracker/1.1");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return true; // the app is a single page; never navigate away from it
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String host = request.getUrl().getHost();
                if (host != null && (host.endsWith("tile.openstreetmap.org")
                        || host.endsWith("server.arcgisonline.com") || host.endsWith("tile.opentopomap.org"))) {
                    return loadTile(request.getUrl().toString(), host + request.getUrl().getPath());
                }
                return null;
            }
        });
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private class Bridge {
        @JavascriptInterface
        public String getState() {
            return TrackService.stateJson(MainActivity.this);
        }

        @JavascriptInterface
        public String getPath(int from) {
            return TrackService.pathJson(from);
        }

        @JavascriptInterface
        public String getActivities() {
            return TrackService.activitiesJson(MainActivity.this);
        }

        @JavascriptInterface
        public String getActivity(String id) {
            try {
                return TrackService.activityJson(MainActivity.this, Long.parseLong(id));
            } catch (NumberFormatException e) {
                return "null";
            }
        }

        @JavascriptInterface
        public void deleteActivity(String id) {
            try {
                TrackService.deleteActivity(MainActivity.this, Long.parseLong(id));
            } catch (NumberFormatException ignored) {
            }
        }

        @JavascriptInterface
        public void setGoal(int goal) {
            TrackService.setGoal(MainActivity.this, goal);
        }

        @JavascriptInterface
        public void start() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    beginTracking();
                }
            });
        }

        @JavascriptInterface
        public void pause() {
            TrackService.setPaused(true);
        }

        @JavascriptInterface
        public void resume() {
            TrackService.setPaused(false);
        }

        @JavascriptInterface
        public void finish() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    stopService(new Intent(MainActivity.this, TrackService.class));
                }
            });
        }

        @JavascriptInterface
        public void discard() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    TrackService.discard = true;
                    stopService(new Intent(MainActivity.this, TrackService.class));
                }
            });
        }
    }

    /**
     * Map tiles are fetched here, not by the page: the map server refuses requests that do not
     * identify the app. Tiles are kept on the phone so each one is downloaded only once.
     */
    private WebResourceResponse loadTile(String url, String path) {
        try {
            File dir = new File(getCacheDir(), "tiles");
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, String.valueOf(path).replaceAll("[^0-9a-zA-Z.]", "_"));
            if (f.exists() && f.length() > 0) {
                return new WebResourceResponse("image/png", null, new FileInputStream(f));
            }
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            c.setRequestProperty("User-Agent", "CholoTracker/1.5 (Android app; com.cholo.tracker)");
            int code = c.getResponseCode();
            if (code != 200) {
                TrackService.mapMsg = "Map server answered " + code;
                c.disconnect();
                return new WebResourceResponse("image/png", null, 404, "Not Found", null, new ByteArrayInputStream(new byte[0]));
            }
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            try (InputStream in = c.getInputStream()) {
                byte[] b = new byte[8192];
                int n;
                while ((n = in.read(b)) > 0) buf.write(b, 0, n);
            }
            c.disconnect();
            byte[] data = buf.toByteArray();
            try (FileOutputStream o = new FileOutputStream(f)) {
                o.write(data);
            }
            TrackService.mapMsg = "";
            return new WebResourceResponse("image/png", null, new ByteArrayInputStream(data));
        } catch (IOException | RuntimeException e) {
            TrackService.mapMsg = "Map needs internet";
            return new WebResourceResponse("image/png", null, 404, "Not Found", null, new ByteArrayInputStream(new byte[0]));
        }
    }

    private void beginTracking() {
        if (TrackService.state != TrackService.IDLE) return;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ArrayList<String> perms = new ArrayList<>();
            perms.add(Manifest.permission.ACCESS_FINE_LOCATION);
            perms.add(Manifest.permission.ACCESS_COARSE_LOCATION);
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS);
            requestPermissions(perms.toArray(new String[0]), REQ_PERMS);
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                && !askedNotif) {
            askedNotif = true;
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_PERMS);
            return;
        }
        TrackService.msg = "";
        startForegroundService(new Intent(this, TrackService.class));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_PERMS) return;
        askedNotif = true;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            beginTracking();
        } else {
            TrackService.msg = "Location permission was not granted. Go to Settings > Apps > Cholo Tracker > Permissions, "
                    + "allow \"Precise\" Location, then tap Start again.";
        }
    }

    @Override
    public void onBackPressed() {
        // let the page close an open activity first; it calls back with "exit" if there is nothing to close
        web.evaluateJavascript("window.onBack ? window.onBack() : 'exit'", new android.webkit.ValueCallback<String>() {
            @Override
            public void onReceiveValue(String v) {
                if (v == null || v.contains("exit")) moveTaskToBack(true);
            }
        });
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
