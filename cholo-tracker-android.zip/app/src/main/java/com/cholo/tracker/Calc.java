package com.cholo.tracker;

import java.util.Locale;

/** Pure calculations with no Android dependencies, so they can be unit-tested on any JVM. */
final class Calc {

    private Calc() {
    }

    /**
     * Fastest time (seconds) in which {@code target} metres were covered anywhere in a recording.
     * d = cumulative distance in metres, t = elapsed seconds, both non-decreasing, n = number of points.
     * Returns -1 when the recording is shorter than the target.
     */
    static double bestEffort(double[] d, double[] t, int n, double target) {
        if (n < 2 || target <= 0 || d[n - 1] - d[0] < target) return -1;
        double best = -1;
        int i = 0;
        for (int j = 1; j < n; j++) {
            if (d[j] - d[0] < target) continue;
            double startD = d[j] - target;
            while (i + 1 < j && d[i + 1] <= startD) i++;
            double span = d[i + 1] - d[i];
            double f = span <= 0 ? 0 : (startD - d[i]) / span;
            double startT = t[i] + f * (t[i + 1] - t[i]);
            double took = t[j] - startT;
            if (took > 0 && (best < 0 || took < best)) best = took;
        }
        return best;
    }

    /**
     * Walk/run decision with smoothing: the mode only flips after two segments in a row disagree
     * with it, so one noisy speed reading never switches it. votes[0] carries the count between calls.
     */
    static boolean nextIsRun(boolean currentlyRun, double speedKmh, double runKmh, int[] votes) {
        boolean fast = speedKmh >= runKmh;
        if (fast == currentlyRun) {
            votes[0] = 0;
            return currentlyRun;
        }
        if (++votes[0] >= 2) {
            votes[0] = 0;
            return fast;
        }
        return currentlyRun;
    }

    /** Smallest move (metres) that counts as real movement for a fix of the given accuracy. */
    static double minStep(float accuracy) {
        return Math.max(5.0, Math.min(accuracy * 0.6, 15.0));
    }

    /** "2", "0.5", "1.5": a distance count the way it should be spoken. */
    static String spokenNumber(double v) {
        if (Math.abs(v - Math.round(v)) < 0.001) return String.valueOf(Math.round(v));
        return String.format(Locale.US, "%.1f", v);
    }

    /** "7 minutes 30 seconds". */
    static String spokenDuration(long secs) {
        long h = secs / 3600, m = (secs % 3600) / 60, s = secs % 60;
        StringBuilder b = new StringBuilder();
        if (h > 0) b.append(h).append(h == 1 ? " hour " : " hours ");
        if (m > 0 || h > 0) b.append(m).append(m == 1 ? " minute " : " minutes ");
        if (h == 0) b.append(s).append(s == 1 ? " second" : " seconds");
        return b.toString().trim();
    }
}
